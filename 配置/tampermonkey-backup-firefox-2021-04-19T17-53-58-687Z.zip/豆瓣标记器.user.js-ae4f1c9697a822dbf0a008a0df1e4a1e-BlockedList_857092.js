// ==UserScript==
// @name               BlockedList_857092
// @namespace          https://github.com/cologler/
// @version            0.3
// @description        try to take over the world!
// @author             cologler
// @grant              GM_getValue
// @grant              GM_setValue
// @grant              GM_addValueChangeListener
// @grant              GM_removeValueChangeListener
// ==/UserScript==

// just let type script work.
(function() { function require(){}; require("greasemonkey"); })();

class BlockedList {
    constructor(key) {
        self._sd = new SingletonData(key, {});
        this._data = self._sd.data;
    }

    loadData() {
        if (this._data === null) {
            this._data = self._sd.data;
        }
    }

    saveData() {
        self._sd.save();
    }

    addId(id, tag) {
        if (!this.hasId(id)) {
            this._data[id] = tag; // can add as group?
            this.saveData();
        }
    }

    removeId(id) {
        if (this.hasId(id)) {
            delete this._data[id];
            this.saveData();
        }
    }

    getTag(id) {
        return this.hasId(id) ? this._data[id]:"";
    }

    hasId(id) {
        return this._data[id] !== undefined;
    }
}


let SingletonData = (() => {
    let names = new Set();
    class SingletonData {
        constructor(key, defaultValue = null) {
            if (typeof key !== 'string') throw 'key must be string';
            if (!key) throw 'key cannot be empty';
            if (names.has(key)) throw `SingletonData <${key}> is created.`;
            names.add(key);

            const unset = {};
            let data = unset;
            let isDisposed = false;

            function ensureSafe() {
                if (isDisposed) throw 'object is disposed.';
            }

            Object.defineProperty(this, 'data', {
                get: () => {
                    ensureSafe();
                    if (data === unset) {
                        data = GM_getValue(key, defaultValue);
                    }
                    return data;
                },
                set: value => {
                    ensureSafe();
                    data = value;
                    GM_setValue(key, value);
                }
            });

            this.save = () => {
                ensureSafe();
                GM_setValue(key, data);
            };

            const listenerId = GM_addValueChangeListener(key, (_, oldValue, newValue, remote) => {
                if (!remote) return;
                data = newValue;
            });
            this.dispose = () => {
                isDisposed = true;
                GM_removeValueChangeListener(listenerId);
                names.delete(key);
            };
        }
    }

    return SingletonData;
})();